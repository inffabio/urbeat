param(
    [string]$InstallDir = "C:\Program Files\Happee Print Agent"
)

$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$startupDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
$startupBat = Join-Path $InstallDir 'happee-print-agent-startup.bat'
$startupShortcut = Join-Path $startupDir 'Happee Print Agent.bat'

Write-Host "[Happee Print Agent] instalando em $InstallDir"

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -Path (Join-Path $sourceDir '*') -Destination $InstallDir -Recurse -Force

if (Test-Path $startupShortcut) {
    Remove-Item $startupShortcut -Force
}

Copy-Item -Path $startupBat -Destination $startupShortcut -Force

Write-Host "[Happee Print Agent] arquivos copiados"
Write-Host "[Happee Print Agent] inicialização automática configurada para o usuário atual"
Write-Host "[Happee Print Agent] execute o dashboard e configure o modo local-agent"
