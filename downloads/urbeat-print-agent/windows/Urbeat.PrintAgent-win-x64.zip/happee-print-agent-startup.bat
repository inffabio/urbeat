@echo off
cd /d "C:\Program Files\Happee Print Agent"
start "Happee Print Agent" /min "C:\Program Files\Happee Print Agent\Happee.PrintAgent.exe"
